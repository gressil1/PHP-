<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php
        include 'header.php';
        include 'connection.php';
    ?>
    <div class="social_apps_htext">
        <h1>Pupular Social Media Apps</h1>
        <h4>In Nowadays!</h4>
    </div>
    <div class="apps_div">
    <?php 
        $sql = "select *from social_media_apps";
        $result = mysqli_query($connection,$sql);
        $num_rows = mysqli_num_rows($result);

        for($i=0;$i<$num_rows;$i++)
        {
            $record = mysqli_fetch_assoc($result);
            echo "<div class='cm_app_list row'>
                    <div class='app_photo col-l-6 col-m-11 col-s-11'>
                        <div class='app_border'>
                            <div class='app_img'>
                                <a href='".$record['applink']."' target='_blank'><img src='".$record['app_photo']."'></a>
                                <a href='".$record['applink']."' target='_blank' class='img_link'>".$record['applink']."</a>
                            </div>
                        </div>
                    </div>
                    <div class='app_desc col-l-5 col-m-11 col-s-11'>
                        <p>".$record['description']."</p>
                        <p class='latest_teqp'><span>Latest Technique: </span>".$record['latest_teq']."</p>
                    </div>
            </div><hr>";
        }
    ?>
    </div>
    <?php
        include 'footer.php';
    ?>
</body>
</html>