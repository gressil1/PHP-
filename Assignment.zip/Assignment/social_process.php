<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include("connection.php"); ?>

    <?php if (isset($_POST['submit'])) {
            $app_name = $_POST['appname'];
            $app_photo_name = $_FILES['app_photo']['name'];
            $tmp_name = $_FILES['app_photo']['tmp_name'];
            $app_photo_path = "socialapp/".$app_photo_name;
            $description = $_POST['description'];
            $link = $_POST['app_link'];
            $teq = $_POST['teq'];
            
                $sql_search = "select *from social_media_apps where appname = '$app_name'";
                $result = mysqli_query($connection,$sql_search);
                $num_rows = mysqli_num_rows($result);
                if($num_rows<1){
                    copy($tmp_name,$app_photo_path);
                    $sql = "Insert into social_media_apps(appname,app_photo,description,applink,latest_teq) values('$app_name','$app_photo_path','$description','$link','$teq')";
                    if(mysqli_query($connection,$sql))
                    echo "<script>
                            alert('App is successfully added!');
                            window.location.href='social_form.php';
                        </script>";
                    else
                    echo "<script>
                            alert('Apps saving error!');
                            window.location.href='social_form.php';
                        </script>";
                }
                else
                    echo "<script>
                            alert('Existing App! Please Re-add the different Apps');
                            window.location.href='social_form.php';
                        </script>";
            }
    ?>
</body>
</html>