<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include 'dashboard_header.php';
    ?>
    <!-- Navigation bar Admin Home Page-->
    <div class="ad-home-title row">
        <div class="ad-detail-num col-l-3 col-m-3 col-s-10">
            <div class="detail-icon">
                <a href="customer.php"><i class="fa-solid fa-user-group"></i></a>
            </div>
            <div class="detail-num">
                <p>Total Viewers</p>
                <p>92384 Views</p>
            </div>
        </div>
        <div class="ad-detail-num col-l-3 col-m-3 col-s-10">
            <div class="detail-icon">
                <a href="customer.php"><i class="fa-solid fa-bullhorn"></i></a>
            </div>
            <div class="detail-num">
                <p>Total Campaign</p>
                <p>438</p>
            </div>
        </div>
        <div class="ad-detail-num col-l-3 col-m-3 col-s-10">
            <div class="detail-icon">
                <a href="message.php"><i class="fa-regular fa-envelope-open"></i></a>
            </div>
            <div class="detail-num">
                <p>Contact Messages</p>
                <p>7994 Messages</p>
            </div>
        </div>
    </div>
<!-- ____________________________-- -->
</body>
</html>