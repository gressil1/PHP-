<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        include 'dashboard_header.php';
        include 'connection.php';
    ?>
    <?php
        $sql = "select *from user";
        $result = mysqli_query($connection,$sql);
        $num_rows = mysqli_num_rows($result);
    ?>
        <div class="ad-cut-title row">
            <div class="cut-num col-l-3 col-m-3 col-s-10">
                <div class="cut-icon">
                    <a href="customer.php"><i class="fa-solid fa-user-group"></i></a>
                </div>
                <div class="cut-dt">
                    <p>Total Viewers</p>
                    <p>92384 Views</p>
                </div>
            </div>
            <div class="cut-num col-l-3 col-m-3 col-s-10">
                <div class="cut-icon">
                    <a href="customer.php"><i class="fa-solid fa-user-pen"></i></a>
                </div>
                <div class="cut-dt">
                    <p>Total Customers</p>
                    <?php
                    echo "<p>$num_rows Users</p>";
                    ?>
                </div>
            </div>
            <div class="cut-num col-l-3 col-m-3 col-s-10">
                <div class="cut-icon">
                    <a href="customer.php"><i class="fa-solid fa-user-clock"></i></a>
                </div>
                <div class="cut-dt">
                    <p>Active Users</p>
                    <?php
                    $activeU = $num_rows-3;
                    echo "<p>$activeU</p>";
                ?>
                </div>
            </div>
        </div>
        <?php
            include 'userlist.php';
        ?>
</body>
</html>