<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    if(isset($_SESSION['role'])){
        if($_SESSION['role']=="Admin"){
            include("connection.php");
            $contact_id = $_GET['id'];
            $sql = "delete from contact where id=$contact_id";

            if(mysqli_query($connection,$sql)){
                echo "<script>
                    alert('Message is Deleted');
                    window.location.href='show_contact.php';
                </script>";
            }
            else{
                echo "Delection Error!<br>";
            }
        }
    }else{
        echo "Administrator only!";
    }
    ?>
</body>
</html>