<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include 'dashboard_header.php';
        include 'connection.php';
    ?>
    <div class="ad-app-title row">
        <div class="ad-app-num col-l-3 col-m-3 col-s-10">
            <div class="app-icon">
                <a href="socialmedia.php"><i class="fa-solid fa-user-group"></i></a>
            </div>
            <div class="app-num">
                <p>Total Viewers</p>
                <p>92384 Views</p>
            </div>
        </div>
        <div class="ad-app-num col-l-3 col-m-3 col-s-10">
            <div class="app-icon">
                <a href="socialmedia.php"><i class="fa-solid fa-mobile-screen"></i></a>
            </div>
            <div class="app-num">
                <p>Total Social Apps</p>
                <?php
                    $sql = "select *from social_media_apps";
                    $result = mysqli_query($connection,$sql);
                    $num_rows = mysqli_num_rows($result);

                    echo "<p>$num_rows</p>"
                ?>
            </div>
        </div>
        <div class="ad-app-num col-l-3 col-m-3 col-s-10">
            <div class="app-icon">
                <a href="social_form.php"><img src="img/icons/add_media.png" alt="add media app"></i></a>
            </div>
            <div class="app-num">
                <p>New Apps</p>
                <a href="social_form.php">Add Apps</a>
            </div>
        </div>
    </div>
    <?php
        for($i=0;$i<$num_rows;$i++)
        {
            $app = mysqli_fetch_assoc($result);

            echo "<div class='cm_app_list row'>
                    <div class='app_photo col-l-6 col-m-11 col-s-11'>
                        <div class='app_border'>
                            <div class='app_img'>
                                <img src='".$app['app_photo']."'>
                                <a href='facebook.com'>".$app['applink']."</a>
                            </div>
                        </div>
                    </div>
                    <div class='app_desc col-l-5 col-m-11 col-s-11'>
                        <p>".$app['description']."</p>
                    </div>
            </div><hr>";
        }
        
    ?>
</body>
</html>