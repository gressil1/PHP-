<!-- <?php
session_start();
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php
        include 'connection.php';
        if(isset($_SESSION['role'])) {
            if($_SESSION['role']=="Admin"){
                echo "<div class='bdy-msg'>";
                    echo "<h3>Messages</h3>";
                    $sql = "select *from contact";
                    $result = mysqli_query($connection,$sql);
                    $num_rows = mysqli_num_rows($result);

                    for($i=0;$i<$num_rows;$i++)
                    {
                        $record = mysqli_fetch_assoc($result);
                        $contact_id = $record['id'];
                        echo "<div class='messages'>
                            <div class='ur_msg_txt'>
                                <p class='sent_name'><span>From: </span>".$record['name']."<span>(".$record['email'].")</span></p>
                                <p class='sent_msg'><span>Sent: </span>".$record['message']."</p>
                            </div>
                            <div class='contact_del_btn'>
                                <a href='deletecontact.php?id=$contact_id'>Delete</a>
                            </div>
                        </div>";
                    }
                }
            echo "</div>";
        }
        else{
            echo "<script>
                    alert('Allow Only for Admin');
                    window.location.href='home.php';
                </script>";
        }
    ?>
</body>
</html>