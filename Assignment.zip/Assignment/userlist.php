<!-- <?php 
session_start();
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php 
        if(isset($_SESSION['role'])){
            if($_SESSION['role']=="Admin"){
                include("connection.php");
                $sql = "select *from user";
                $result = mysqli_query($connection,$sql);
                $num_rows = mysqli_num_rows($result);

                include 'search_user.php';

                echo "<div class='userlist'>";
                echo "<table class='list-table'>";
                echo "<thead>
                    <tr>
                        <th>No</th>
                        <th>Profile</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Remark</th>
                        <th>Edit</th>
                    </tr>
                </thead>";

                for($i=0;$i<$num_rows;$i++){
                    $user = mysqli_fetch_assoc($result);
                    $user_id =$user['id'];
                    
                    echo "<tbody>";
                    echo "<tr class='active-row'>";
                    echo "<td>".($i+1)."</td>";
                    echo "<td><img src='". $user['profile']."'></td>";
                    echo "<td>". $user['firstname']."</td>";
                    echo "<td>".$user['lastname']."</td>";
                    echo "<td>".$user['email']."</td>";
                    echo "<td>".$user['address']."</td>";
                    echo "<td>".$user['phone_number']."</td>";
                    echo "<td>".$user['role']."</td>";
                    echo "<td>".$user['remark']."</td>";
                    echo "<td>
                                <a href='updateuser.php?id=$user_id' class='update'>Update</a> ||
                                <a href='deleteuser.php?id=$user_id' class='delete'>Delete</a>
                        </td>";
                    
                    echo "</tr>";
                    echo "</tbody>";

                }//end for
                echo "</table>";
                echo "</div>";
            }
            else{
                echo "Administrator only!<br>";
            }
        }
        else{
            echo "Please login at first!<br>";
        }
    ?>
</body>
</html>