<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

        echo "<footer>";
            echo "<div class='row'> ";
                echo "<div class='ft'>";
                    echo "<ul class='col-l-4 col-m-4 col-s-12'>
                            <li>About Us</li>
                            <li><a href='Home.php'>Home</a></li>
                            <li><a href='#'>Jobs</a></li>
                            <li><a href='contact.php'>Contact Us</a></li>
                            <li><a href='login.php'>Log in</a></li>
                            <li><a href='#'>Rewards</a></li>
                          </ul>";
                    echo "<ul class='col-l-4 col-m-4 col-s-12' >
                    <li>Resources</li>
                    <li><a href='#'>Terms of Use</a></li>
                    <li><a href='#'>Accessibility Statement</a></li>
                    <li><a href='#'>Privacy Policy</a></li>
                    </ul>";
                    echo "<ul class='col-l-4 col-m-4 col-s-12'>
                            <li>Contact us</li>
                            <li><a href='#'>Phone:+8643937583</a></li>
                            <li><a href='#'>Email:asurapyae58@gmail.com</a></li>
                            <li><a href='#'>Help & FAQ</a></li>
                            <li><a href='#'>Accessibility Statement</a></li>
                          </ul> ";
                echo "</div>";
            echo "</div>";
            echo "<div class='Cr-social'>";
                    echo "<div class='copy-right'>&copy;SMC (social media campaign)@2024
                          </div>";
                    echo "<div class='social-media-icons'>
                            <a href='https://www.facebook.com' target='_blank'>
                                <img src='Img/Icons/facebook.jpg' alt='facebook'>
                            </a>
                            <a href='https://www.youtube.com' target='_blank'>
                                <img src='Img/Icons/youtube.jpg' alt='youtube'>
                            </a>
                            <a href='https://www.twitter.com' target='_blank'>
                                <img src='Img/Icons/twitter.jpg' alt='twitter'>
                            </a>
                            <a href='https://www.instagram.com' target='_blank'>
                                <img src='Img/Icons/instagram.jpg' alt='instagram'>
                            </a>
                          </div>";
            echo "</div>";
    ?>
</body>
</html>