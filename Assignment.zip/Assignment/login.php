<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php
        include 'header.php';
    ?>
    <div id="login">
        <h2>Login Your Account!</h2>
        <form action="login_process.php" method="post">
            <input type="text" class="login" name="uname" placeholder="username">
            <input type="text" class="login" name="pws" placeholder="Password">
            <input type="submit" class="login-but" name="submit" value="Login">
            <input type="reset" class="login-but" name="reset" value="Clear">
            <div class="g-t-reg">
                <p>Don't You Have Account! Go to <a href="reg.php">Register..</a></p>
            </div>
        </form>
    </div>
</body>
</html>