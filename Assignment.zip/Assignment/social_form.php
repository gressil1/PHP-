<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php
        include 'dashboard_header.php';
    ?>
    <?php
        // include 'connection.php';
        // if(isset($_SESSION['role'])) {
        //     if($_SESSION['role']=="Admin"){
                echo "<div class='social_form'>
                    <h3>Do You want to Add An Social App!</h3>
                    <form action='social_process.php' method='post' enctype='multipart/form-data'>
                        <input type='text' class='social' name='appname' placeholder='App Name...' required>
                        <label>App Photo: </label>
                        <input type='file' class='app_photo_fold' name='app_photo'>
                        <label>Description</label>
                        <textarea name='description' class='desc' placeholder='Descriptionn For Apps'></textarea>
                        <label>Link</label>
                        <textarea name='app_link' class='textarea' placeholder='App Link'></textarea>
                        <label>Latest Technique</label>
                        <textarea name='teq' class='textarea' placeholder='Latest Technique'></textarea>
                        <input type='submit' class='sc_btn' name='submit' value='Add'>
                        <input type='reset' class='sc_btn' name='reset' value='Clear'>
                    </form>
                </div>";
            //     }
            // }
            // else
            //     echo "<script>
            //         alert('Allow Only for Admin');
            //         window.location.href='home.php';
            //     </script>";
            
        ?>
</body>
</html>