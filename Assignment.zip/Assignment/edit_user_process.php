<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Update</h1>
    <?php
    if(isset($_SESSION['role'])){
        if($_SESSION['role']=="Admin"){
            include("connection.php");
            $user_id = $_POST['user_id'];
            $role = $_POST['role'];
            $remark =$_POST['remark'];

            $sql = "update user set role = '$role',remark='$remark' where id=$user_id";

            if(mysqli_query($connection,$sql)){
                echo "Updated User!<br>";
                echo "<a href = 'userlist.php'> Go to User List</a>";
            }
            else{
                echo "Updating Fail<br>";
            }
        }
        else{
            echo "Administrator only!<br>";
        }
    }
    ?>
</body>
</html>