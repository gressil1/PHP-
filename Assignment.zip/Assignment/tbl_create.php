<?php
    $host = "localhost";
    $username = "root";
    $password = "";

    $dbname = "smcampaigndb";

    $connection = mysqli_connect($host,$username,$password,$dbname);

    if($connection) 
        echo "Database connection established!<br>";
    else 
        echo "Database Connection Failed";


        $sql = "create table if not exists social_media_apps(
        id int auto_increment primary key,
        appname varchar(50),
        app_photo text,
        description varchar(500),
        applink text,
        latest_teq varchar(50)
        )";

        // $sql = "create table if not exists user(
        //     id int auto_increment primary key, 
        //     firstname varchar(25),
        //     lastname varchar(25),
        //     username varchar(30),
        //     email varchar(100),
        //     address varchar(100),
        //     phone_number varchar(50),
        //     password varchar(500),
        //     gender varchar(10),
        //     profile text,
        //     role varchar(30),
        //     remark varchar(50)
        //     )";

    // $sql = "create table if not exists contact(
    //         id int auto_increment primary key, 
    //         name varchar(50),
    //         email varchar(100),
    //         message text)";


    if(mysqli_query($connection,$sql))
        echo "social_media_apps table is created!<br>";
    else 
        echo "Table creation Error! <br>";




?>