<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
    <script src='https://www.google.com/recaptcha/api.js' async defer>
    </script>
</head>
<body>
    <?php
        include 'header.php';
    ?>
    <div class="reg-back row">
        <div class="reg-text col-l-5 col-m-11 col-s-11">
            <h1>Register Today and Be a Part of Something Bigger!</h1>
            <p>By signing up, you’ll receive updates, volunteer opportunities,
                 event invites, and resources to help make a difference. Together, 
                 we can create lasting change.</p>
        </div>
        <div class="register col-l-5 col-m-11 col-s-11">
            <h3>Register An Account!</h3>
            <form action="reg_process.php" method="post" enctype="multipart/form-data">
                <input type="text" class="regname" name="fname" placeholder="First Name..." required>
                <input type="text" class="regname" name="lname" placeholder="Last name..." required>
                <input type="text" class="reg" name="uname" placeholder="UserName..." required>
                <input type="email" class="reg" name="email" placeholder="Email..." required>
                <input type="text" class="reg" name="address" placeholder="Address...">
                <input type="text" class="reg" name="phone" placeholder="Phone Number..." required>
                <input type="password" class="reg" name="pws" placeholder="Password" required>
                <input type="password" class="reg" name="confirm_pws" placeholder="Confirm Password..." required><br><br>
                <label>Gender: </label>
                <input type="radio" class="gender" name="gender" value="Male">Male
                <input type="radio" class="gender" name="gender" value="Female">Female
                <input type="radio" class="gender" name="gender" value="none">None<br><br>
                <label>Profile Picture: </label>
                <input type="file" name="profile">
                <div class="g-recaptcha" data-type="image"  data-sitekey="6LcrIzAqAAAAAM6p99qazGL0LpJNdEnvEDlCTmiT"></div>
                <input type="submit" class="reg_button" name="submit" value="Register">
                <input type="reset" class="reg_button" name="reset" value="Clear">
                <div id="reg-in">
                    <p>Already have an Account? Please <a href="login.php">Login..</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>