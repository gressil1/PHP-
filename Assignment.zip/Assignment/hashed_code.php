<?php

$admin_pw = "admin@123";

$hashed = password_hash($admin_pw, PASSWORD_DEFAULT);

echo $hashed;
?>