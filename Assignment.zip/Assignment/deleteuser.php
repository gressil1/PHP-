<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Delete User!</h1>
    <?php
    if(isset($_SESSION['role'])){
        if($_SESSION['role']=="Admin"){
            include("connection.php");
            $user_id = $_GET['id'];
            $sql = "delete from user where id=$user_id";

            if(mysqli_query($connection,$sql)){
                echo "<script>
                    alert('User Record is Deleted');
                </script>";
            }
            else{
                echo "Delection Error!<br>";
            }
        }
    }else{
        echo "Administrator only!";
    }
    ?>
</body>
</html>