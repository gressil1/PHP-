<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include("connection.php"); ?>
    <h1>Register Process</h1>
    <?php if (isset($_POST['submit'])) {
        ////////////////////////////

        if(isset($_POST['g-recaptcha-response'])){
 
            $captcha=$_POST['g-recaptcha-response'];
   
        }
          if(!$captcha){
   
            echo "<script>
            alert('Please check the the captcha form!');

            window.location.href='reg.php';
            </script>";
   
            exit;
   
          }
          $secretKey = "6LcrIzAqAAAAAGQ03tjAi7BX5KkAmVQ1j62Y5T5U";
          $ip = $_SERVER['REMOTE_ADDR'];
          // post request to server
   
          $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
          $response = file_get_contents($url);
   
          $responseKeys = json_decode($response,true);
          // should return JSON with success as true
   
          if($responseKeys["success"]) {
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $uname = $_POST['uname'];
            $email = $_POST['email'];
            $address = $_POST['address'];
            $phnum = $_POST['phone'];
            $pws = $_POST['pws'];
            $confirm_pws = $_POST['confirm_pws'];
            $gender = $_POST['gender'];
            $profile_name = $_FILES['profile']['name'];
            $tmp_name = $_FILES['profile']['tmp_name'];
            $profile_path = "upload/".$profile_name;
            
            if($pws == $confirm_pws){
                $sql_search = "select *from user where username = '$uname'";
                $result = mysqli_query($connection,$sql_search);
                $num_rows = mysqli_num_rows($result);
                if($num_rows<1){
                    copy($tmp_name,$profile_path);
                    $hashed_pws = password_hash($pws,PASSWORD_DEFAULT);
                    $sql = "Insert into user(firstname,lastname,username,email,address,phone_number,password,gender,profile,role,remark) values('$fname','$lname','$uname','$email','$address','$phnum','$hashed_pws','$gender','$profile_path','user','no remark')";
                    if(mysqli_query($connection,$sql))
                        echo "User record is successfully saved!";
                    else
                        echo "Record Saving Error!";
                }
                else{
                    echo "Existing username! Please Re-enter with different username<br>"; 
                }
            }
            else{
                echo "Not match your password! Please Re-enter the password<br>";
            }
   
          }
           else {
   
                  echo "<script>alert('<h2>reCaptcha verification failed!');</script>";
   
          }
            
        }
    ?>
</body>
</html>