<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php
    include 'connection.php';
    include 'search_user.php';
    ?>
    <?php
    if(isset($_SESSION['role'])) {
        if(isset($_SESSION['role']) == "Admin") {
            $keyword = $_POST['keyword'];
            $sql = "select * from user 
            where firstname LIKE '%$keyword%' OR
            lastname LIKE '%$keyword%' OR
            email LIKE '%$keyword%' ";

                $result = mysqli_query($connection,$sql);
                $num_rows = mysqli_num_rows($result);
                

                if($num_rows==0){
                    echo "<script>
                    alert('No user in the list');
                    window.location.href ='userlist.php';
                    </script>";
                }else{
                    echo "<div class='userlist'>";
                    echo "<table class='list-table'>";
                    echo "<thead>";
                    echo "<tr>
                        <th>No</th>
                        <th>Profile</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Remark</th>
                        <th>Edit</th>
                        </tr>";
                    echo "</thead>";

                    for($i=0;$i<$num_rows;$i++){
                        $user = mysqli_fetch_assoc($result);
                        $user_id =$user['id'];
                        
                        echo "<tbody>";
                        echo "<tr class='active-row'>";
                        echo "<td>".($i+1)."</td>";
                        echo "<td><img src='". $user['profile']."'width ='100px' height ='100px'> </td>";
                        echo "<td>". $user['firstname']."</td>";
                        echo "<td>".$user['lastname']."</td>";
                        echo "<td>".$user['email']."</td>";
                        echo "<td>".$user['address']."</td>";
                        echo "<td>".$user['phone_number']."</td>";
                        echo "<td>".$user['role']."</td>";
                        echo "<td>".$user['remark']."</td>";
                        echo "<td>
                                    <a href='updateuser.php?id=$user_id' class='update'>Update</a> ||
                                    <a href='deleteuser.php?id=$user_id' class='delete'>Delete</a>
                            </td>";
                        
                        echo "</tr>";
                        echo "</tbody>";

                    }//end for
                    echo "</table>";
                    echo "</div>";
                }

        }
    }else{
        echo "<script>
        alert('Adiministrator only!');
        </script>";
    }
    ?>
</body>
</html>