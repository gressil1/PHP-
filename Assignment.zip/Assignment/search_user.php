<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        echo "<div class='search-user'>
            <form action='search_user_process.php' method='POST'>
                <input type='text' class='inuser' name = 'keyword' placeholder='Enter any keyword'>
                <input type='submit' class='btn' name='submit' value='Search'>
                <input type='reset' class='btn' name='reset' value='Clear'>
            </form>
        </div>";
    ?>
</body>
</html>