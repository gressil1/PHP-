<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>
<?php

echo "<header>";
    echo "<nav class='nav'>";
        echo "<div class='logo'>";
            echo "<img src='img/dsg-img/logo.png' alt='SMC logo'>";
        echo "</div>";
        echo "<ul>";
            echo "<li><a href='home.php'>Home</a></li>";
            echo "<li><a href='login.php'>LogIn</a></li>";
            echo "<li><a href='contact.php'>Contact Us</a></li>";
            echo "<li>";
                echo "<div class='drop-div'>";
                    echo "<button class='drop-text'>All Catagories</button>";
                    echo "<div class='drop-item'>";
                        echo "<a href='info.php'>Information</a>";
                        echo "<a href='mpsma.php'>Most Popular Social Media Apps</a>";
                        echo "<a href='parents-help.php'>How Parents Can Help</a>";
                        echo "<a href='livestream.php'>Live Streaming</a>";
                        echo "<a href='legislation.php'>Legislation and Guidance</a>";
                    echo "</div>";
                echo "</div>";
            echo"</li>";
        echo "</ul>";
        echo "<div class='menu'>
            <i class='fa-solid fa-bars'></i>
        </div>";
    echo "</nav>";
    echo "<div class='menu-list'>
            <li><a href='home.php'>Home</a></li>
            <li><a href='info.php'>Information</a></li>
            <li><a href='mpsma.php'>Most Popular Social Media Apps</a></li>
            <li><a href='parents-help.php'>How Parents Can help</a></li>
            <li><a href='livestream.php'>Live Stream</a></li>
            <li><a href='legislation.php'>Legislation</a></li>
            <li><a href='contact.php'>Contact</a></li>
            <li><a href='login.php'>LogIn</a></li>
          </div>";
echo "</header>";

echo "<script>
        const menuBtn = document.querySelector('.menu')
        const menuIcon = document.querySelector('.menu i')
        const dropDownMenu = document.querySelector('.menu-list')

        menuBtn.onclick = function(){
            dropDownMenu.classList.toggle('open')
            const isOpen = dropDownMenu.classList.contains('open')

        menuIcon.classList = isOpen
            ?'fa-solid fa-xmark'
            :'fa-solid fa-bars'
        }
      </script>";
?>
</body>
</html>