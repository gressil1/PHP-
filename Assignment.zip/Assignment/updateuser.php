<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if(isset($_SESSION['role'])){
        if($_SESSION['role']=="Admin"){
            include("connection.php");
            $user_id = $_GET['id'];
            $sql = "select *from user where id =$user_id";
            $result = mysqli_query($connection,$sql);
            $user = mysqli_fetch_assoc($result);
            $role = $user['role'];
            $remark = $user['remark'];

            echo "<form action='edit_user_process.php' method='POST'>
                <input type ='hidden' name = 'user_id' value='$user_id'>
                <label>Role: </label>
                <input type='text' name='role' value='$role'><br>
                <label>Remark: </label>
                <input type='text' name='remark' value='$remark'><br>
                <input type='submit' name='submit' value='Update'>
                <input type='reset' name='reset' value='Clear'>
            </form>";
        }
    }
    ?>
</body>
</html>