<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>
    <?php 
        include 'header.php';
    ?>
    <section>
        <?php

            if(isset($_POST['submit'])){
                
                $name = $_POST['name'];
                $email = $_POST['email'];
                $message = $_POST['message'];

                include 'connection.php';

                $sql = "insert into contact(name,email,message) values ('$name','$email','$message')";

                if(mysqli_query($connection,$sql)) {
                    echo "<script>
                    alert('Your message is sent')
                    window.location.href ='home.php';
                    </script>";
                }
                
            }
            else{


        ?>
            <div class="contact-div row">
                <div class="contact-text col-l-6 col-m-11 col-s-11">
                    <div id="contact-text">
                        <h1>Contact Us</h1>
                        <p>Feel free to get in touch with us through any of <br>the following means. Whether you have inquiries, <br>collaboration opportunities, or just want to say <br>hello, we're here to listen</p>
                    </div>
                    <div id="con-fact">
                        <h1>Get in Touch</h1>
                        <p><i class="fa-solid fa-phone-volume"></i><a href="#">+86 332 223 334</a></p>
                        <p><i class="fa-regular fa-envelope"></i><a href="gmail.com">smc1@office.edu.com</a></p>
                    </div>
                </div>
                <div class="contact-form col-l-6 col-m-11 col-s-11">
                    <div id="contact-form-div">
                        <h1>Contact With Our Team</h1>
                        <form action="contact.php" method="post">
                            <label>Name</label>
                            <input type="text" class="con-input" name="name" placeholder="Your Name">
                            <label>Email</label>
                            <input type="text" class="con-input" name="email" placeholder="Enter Your Email">
                            <label>Message</label>
                            <textarea name="message" id="textarea" placeholder="Your Message"></textarea>
                            <input type="submit" class="send" name="submit" value="Send">
                        </form>
                    </div>
                </div>
            </div>
        <?php
            }
        ?>
    </section>
    <?php
        include 'footer.php';
    ?>
</body>
</html>