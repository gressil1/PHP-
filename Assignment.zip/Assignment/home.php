<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<script type="text/javascript">
    function googleTranslateElementInit() {
 
    new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    }
</script>
<body>
    <?php
        include 'header.php';
    ?>
    <section>
        <div id="gg-tran">
            <div id="google_translate_element"></div>
            <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        </div>
        <div id="wel-text">
            <h1><span>Welcome From </span>Our Campaign, Dear My Customer</h1>
        </div>
        <div class="intro_digital row">
            <div class="digital_txt col-l-4 col-m-11 col-s-11">
                <h3>Your Partner In Digital Marketing</h3>
                <p>Based in Yangon, Social Media Campaign
                     specializes in crafting dynamic and 
                     engaging social media strategies that 
                     connect brands with their audience. Our team 
                     of experts understands the local market and 
                     leverages the latest trends to deliver impactful
                      campaigns that drive results. We are 
                      committed to helping businesses grow their
                       online presence and achieve their marketing
                        goals.</p>
            </div>
            <div class="digital_img col-l-4 col-m-11 col-s-11">
                <img src="img/dsg-img/home-img1.jpg" alt="digital marketings image">
            </div>
        </div>
        <div class="sec_intro">
            <div class="sec_int_fold row">
                <div class="req">
                    <img src="" alt="">
                    <a href=""></a>
                    <p></p>
                </div>
                <div class="req">
                    <img src="" alt="">
                    <a href=""></a>
                    <p></p>
                </div>
                <div class="req">
                    <img src="" alt="">
                    <a href=""></a>
                    <p></p>
                </div>
            </div>
        </div>
    </section>
    <?php
        include 'footer.php';
    ?>
</body>
</html>