<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        include("connection.php");
        $uname = $_POST['uname'];
        $pws = $_POST['pws'];

        $sql = "select *from user where username = '$uname'";

        $result = mysqli_query($connection,$sql);
        $num_rows = mysqli_num_rows($result);

        if($num_rows == 1){
            $record = mysqli_fetch_assoc($result);
            $hashed_pws = $record['password'];

            if(password_verify($pws,$hashed_pws)){
                if($uname=="admin" && $record['role']=="Admin"){
                    $_SESSION['role']="Admin";

                    include("dashboard.php");
                }
                else{
                    include("home.php");
                }
            }
            else{
                echo "Invalid password!";
            }
        }
        else{
            echo "Invalid user! Please Register";
        }
    ?>
</body>
</html>