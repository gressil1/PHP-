<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>
    <?php
    echo "<header id='ad-hd'>
            <nav class='ad-nav'>
                <div class='ad-menu'>
                    <i class='fa-solid fa-bars'></i>
                </div>
                <div class='ad-title'>
                    <h3>SMC Admin Dashboard</h3>
                </div>
            </nav>
            <div class='ad-menu-list'>
                <div><a href='dashboard.php'><i class='fa-solid fa-house'></i>Home</a></div>
                <div><a href='customer.php'><i class='fa-solid fa-users-gear'></i>Customers</a></div>
                <div><a href='socialmedia.php'><i class='fa-solid fa-mobile-screen'></i>Social Media Apps</a></div>
                <div><a href='message.php'><i class='fa-regular fa-message'></i>Messages</a></div>
                <div><a href='logout.php'><i class='fa-solid fa-right-from-bracket'></i>Log Out</a></div>
            </div>
          </header>";
    echo "<script>
            const menuBtn = document.querySelector('.ad-menu')
            const menuIcon = document.querySelector('.ad-menu i')
            const dropDownMenu = document.querySelector('.ad-menu-list')

            menuBtn.onclick = function(){
                dropDownMenu.classList.toggle('open')
                const isOpen = dropDownMenu.classList.contains('open')

            menuIcon.classList = isOpen
                ?'fa-solid fa-xmark'
                :'fa-solid fa-bars'
            }
          </script>";
    ?>
</body>
</html>