<!-- <?php 
    session_start();
?> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?<?php echo time(); ?>">
</head>
<body>
    <?php
        include 'dashboard_header.php';
        include 'connection.php';
    ?>
    <!-- navigation bar for Messages -->
    <div class="ad-msg-title row">
        <div class="msg-num col-l-3 col-m-3 col-s-10">
            <div class="msg-icon">
                <a href="customer.php"><i class="fa-solid fa-user-group"></i></a>
            </div>
            <div class="msg-dt">
                <p>Total Viewers</p>
                <p>92384 Views</p>
            </div>
        </div>
        <div class="msg-num col-l-3 col-m-3 col-s-10">
            <div class="msg-icon">
                <a href="message.php"><i class="fa-regular fa-envelope-open"></i></a>
            </div>
            <div class="msg-dt">
                <p>Total Messages</p>
                <?php
                    $sql = "select *from contact";
                    $result = mysqli_query($connection,$sql);
                    $num_rows = mysqli_num_rows($result);

                    echo "<p>$num_rows Mails</p>";
                ?>
            </div>
        </div>
        <div class="msg-num col-l-3 col-m-3 col-s-10">
            <div class="msg-icon">
                <a href="message.php"><i class="fa-regular fa-envelope"></i></a>
            </div>
            <div class="msg-dt">
                <p>Unread Messages</p>
                <?php
                    $unread = $num_rows-2;
                    echo "<p>$unread</p>";
                ?>
            </div>
        </div>
    </div>
    <!-- ________________________ -->

    <!-- Body for Messages -->
        <div class="msg-bdy">
            <div class="msg-bdy-icon">
                <i class="fa-regular fa-envelope"></i>
            </div>
            <div class="msg-bdy-txt">
                <h3>New Message<span>*</span></h3>
                <p><a href="show_contact.php">You have new mesages</a></p>
            </div>
            <div class="msg-bdy-mar">
                <button><a href="show_contact.php">Go to Read</a></button>
                <button>Mask as Read</button>
            </div>
        </div>

    <!-- _________________ -->
</body>
</html>